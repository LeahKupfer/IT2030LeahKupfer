﻿using LeahSporting.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace LeahSporting.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        [HttpGet]
        public IActionResult Index()
        {
          
            return View();
        }
        [HttpGet]
        public IActionResult Tools()
        {
            HttpContext.Session.SetString("Course", "IT2030");
            HttpContext.Session.SetString("StudentID", "S01221525");
            HttpContext.Session.SetInt32("CurrentDate", 20221204);


            ViewBag.TaxAmount = 0;
            ViewBag.TotalSalePrice = 0;
            return View();
        }

        [HttpPost]
        public IActionResult Tools(Sale productSale)
        {
            if (ModelState.IsValid)
            {
                ViewBag.TaxAmount = productSale.TaxAmount();
                ViewBag.TotalSalePrice = productSale.TotalSalePrice();
            }
            else
            {
                ViewBag.TaxAmount = 0;
                ViewBag.TotalSalePrice = 0;
            }
          
            return View(productSale);
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult FAQ()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}