﻿using System.ComponentModel.DataAnnotations;

namespace LeahSporting.Models
{
    public class Customer
    {
        [Required(ErrorMessage = "Please enter a first name")]
        [StringLength(10, ErrorMessage = "First name must be 10 characters or less.")]
        [RegularExpression("^[a-zA-Z]+$",
            ErrorMessage ="First name may not contain numbers or special characters.")]
        public string? FirstName { get; set; }

        [Required(ErrorMessage = "Please enter a last name")]
        [StringLength(10, ErrorMessage = "Last name must be 10 characters or less.")]
        [RegularExpression("^[a-zA-Z]+$",
            ErrorMessage = "Last name may not contain numbers or special characters.")]
        public string? LastName { get; set; }

        [Required(ErrorMessage = "Please enter a street address")]
        public string? StreetAddress { get; set; }

        [Required(ErrorMessage = "Please enter a city")]
        public string? City { get; set; }

        [Required(ErrorMessage = "Please enter a state")]
        [StringLength(2, ErrorMessage = "State must be 2 characters only.")]
        [RegularExpression("[a-zA-Z]{2}",
          ErrorMessage = "State may not contain numbers or special characters.")]
        public string? State { get; set; }

        [Required(ErrorMessage = "Please enter a zip")]
        [StringLength(5, ErrorMessage = "Zip code must be 5 digits.")]
        [RegularExpression("[0-9]{5}",
         ErrorMessage = "Zip code may not contain letters or special charaacters and must be 5 digits.")]
        public string? ZipCode { get; set; }

        [Required(ErrorMessage = "Please enter a phone number")]
        [StringLength(10, ErrorMessage = "Phone number must be 10 digits.")]
        [RegularExpression("[0-9]{10}",
         ErrorMessage = "Phone number may not contain letters or special charaacters and must be 10 digits.")]
        public string? PhoneNumber { get; set; }

        [Required(ErrorMessage = "Please enter an email")]
        public string? Email { get; set; }
    }

}


